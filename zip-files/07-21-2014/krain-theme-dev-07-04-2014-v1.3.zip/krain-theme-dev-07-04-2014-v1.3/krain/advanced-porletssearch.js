function Quicksearchbutton(){
    $('.portletQuickSearch .formControls').after('<a class="Quicksearchbutton" href="http://kraincostarica.com/en/search-properties">Advanced search</a>');
}

$(document).ready(function () {
    Quicksearchbutton();
});